import QtQuick
import "../Singletons"

/**
 * One pet per overlay. Surfaces declare PetPerch items that register here; the
 * actor is reparented into the highest-priority available perch, so it inherits
 * that surface's opacity, morph and motion without copying any geometry. With
 * no perch the actor is hidden and none of its timers run.
 */
Item {
    id: petLayer

    property bool monitorActive: false
    property real s: 1

    property var perches: []
    property int revision: 0
    // Perches read this instead of calling into a layer that is going away.
    property bool closing: false
    Component.onDestruction: closing = true

    // The best perch right now. Surfaces hand over within one event (the
    // launcher closing, the clock fading back), so the pet follows only the
    // settled result: one move, never a flicker through the bar.
    readonly property Item candidatePerch: {
        void revision
        if (!monitorActive || !PetPack.ready) return null
        let best = null
        for (const perch of perches) {
            if (perch.available && (best === null || perch.priority > best.priority)) best = perch
        }
        return best
    }
    property Item activePerch: null
    onCandidatePerchChanged: settleTimer.restart()
    // A child timer dies with the layer, unlike a deferred call.
    Timer {
        id: settleTimer
        interval: 0
        onTriggered: petLayer.activePerch = petLayer.candidatePerch
    }
    readonly property Item actor: petActor
    readonly property bool petVisible: petActor.shown
    readonly property string perchId: activePerch ? activePerch.perchId : ""
    // At the pixel size the current perch allows: the body's width, how far
    // any pose reaches right of its centre, and how tall the tallest pose is.
    readonly property real bodyWidth: petActor.hit[2] * petActor.px
    readonly property real reachRight: petActor.reachRight * petActor.px
    readonly property int reachRows: petActor.reachRows

    function register(perch) {
        if (perches.indexOf(perch) >= 0) return
        perches.push(perch)
        revision++
    }
    function unregister(perch) {
        const index = perches.indexOf(perch)
        if (index < 0) return
        perches.splice(index, 1)
        revision++
    }
    function notify(kind) { petActor.handleEvent(kind) }

    PetActor {
        id: petActor
        perch: petLayer.activePerch
        parent: petLayer.activePerch || petLayer
        s: petLayer.s
        desiredPx: Config.pets.scale === "small" ? 1 : Config.pets.scale === "large" ? 3 : 2
        sleepEnabled: Config.pets.sleepEnabled
        sleepAfterMs: Math.round(Math.max(1, Config.pets.sleepAfter) * 60000)
    }
}
