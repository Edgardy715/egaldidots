import QtQuick

/**
 * One atlas frame at an integer pixel scale. The strip is a single texture;
 * changing frame only moves it behind a clip, so animating never reloads or
 * re-decodes the image.
 */
Item {
    id: root

    property url source
    property int frame: 0
    property int frameCount: 1
    property int frameWidth: 20
    property int frameHeight: 20
    property int px: 2
    property bool mirrored: false

    width: frameWidth * px
    height: frameHeight * px
    clip: true

    Image {
        // A mirrored strip runs right to left, so frame i sits at the far end.
        x: -(root.mirrored ? root.frameCount - 1 - root.frame : root.frame) * root.width
        width: root.frameCount * root.width
        height: root.height
        source: root.source
        sourceSize.width: root.frameCount * root.frameWidth
        sourceSize.height: root.frameHeight
        fillMode: Image.Stretch
        mirror: root.mirrored
        smooth: false
        mipmap: false
        asynchronous: false
        cache: true
    }
}
