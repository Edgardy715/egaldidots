import QtQuick
import "../Singletons"

/**
 * The pet itself: a state machine over the package's animations.
 *
 * Cost rules: a single-shot frame timer runs only while the current animation
 * has more than one frame to show; a single-shot brain timer picks idle
 * behaviour every few seconds; a sleep timer waits for inactivity. Hidden or
 * asleep, none of them run and the sprite is a still image. Reduced motion
 * keeps one still pose per state: no walking, no idle behaviour.
 */
Item {
    id: actor

    property Item perch: null
    property real s: 1
    property int desiredPx: 2
    property bool sleepEnabled: true
    property int sleepAfterMs: 120000

    readonly property var pack: PetPack.data
    readonly property bool reduced: Flags.reduceMotion
    readonly property bool shown: perch !== null && pack !== null
    readonly property var hit: pack ? pack.hit : [0, 0, 1, 1]
    readonly property int canvasW: pack ? pack.canvas.width : 1
    readonly property int canvasH: pack ? pack.canvas.height : 1
    readonly property int footRow: pack ? pack.canvas.baseline : 1
    readonly property int originX: pack ? pack.canvas.originX : 0
    readonly property int bodyRows: Math.max(1, footRow - hit[1])
    // How far any pose reaches past the body: [left, top, right, bottom) in canvas cells.
    readonly property var bounds: pack && pack.bounds ? pack.bounds : [hit[0], hit[1], hit[0] + hit[2], footRow]
    readonly property int reachRows: Math.max(bodyRows, footRow - bounds[1])
    readonly property int reachRight: Math.max(hit[0] + hit[2], bounds[2]) - originX
    readonly property int basePx: Math.max(1, Math.round(desiredPx * s))
    // A perch never grows for the pet: past its headroom the pixels shrink. A
    // niche centres the body inside its own padding; a line or edge has content
    // above it, so there every pose must fit.
    readonly property int px: perch
        ? Math.max(1, Math.min(basePx, Math.floor(perch.headroom / (perch.kind === "niche" ? bodyRows : reachRows))))
        : basePx

    // Behaviour state.
    property string anim: ""
    property var current: null
    property int step: 0
    property int loops: 0
    property bool settled: false
    property bool asleep: false
    property real posX: 0
    property real walkTarget: 0
    property int walkDir: 0
    property real lastWalk: 0
    property var clickTimes: []
    property real lastHappy: 0
    property real strokeLastX: -1
    property int strokeDir: 0
    property int strokes: 0
    property real strokeStart: 0

    readonly property real centerX: perch ? Math.max(perch.minX, Math.min(perch.maxX, posX)) : 0
    readonly property bool edgePose: current !== null && current.edge === true
    // Which timers are alive; the cost contract is that a still pet has none ticking.
    readonly property bool animating: frameTimer.running
    readonly property bool thinking: brainTimer.running
    readonly property bool sleepArmed: sleepTimer.running

    visible: shown
    opacity: perch ? perch.reveal : 0
    width: canvasW * px
    height: canvasH * px
    x: Math.round(centerX - originX * px)
    y: !perch ? 0 : Math.round(perch.kind === "niche"
        ? perch.height / 2 - (hit[1] + footRow) / 2 * px
        : perch.floorY - footRow * px)
    z: 50
    Accessible.ignored: true

    function baseAnim() {
        if (asleep) return "sleep"
        if (perch && perch.mood === "music") return "dance"
        return "idle"
    }

    function play(name) {
        // Reset the step first so the sprite never indexes the new strip with an old step.
        step = 0
        current = PetPack.animation(name)
        anim = name
        loops = 0
        settled = false
        if (name !== "walk") walkDir = 0
        schedule()
    }

    function schedule() {
        frameTimer.stop()
        if (!shown || current === null || settled) return
        if (reduced) {
            // One still pose; a one-shot animation still ends on time.
            if (!current.loop) {
                frameTimer.interval = current.ms.reduce((sum, value) => sum + value, 0)
                frameTimer.start()
            }
            return
        }
        if (current.loop && current.f.length === 1) return
        frameTimer.interval = current.ms[step]
        frameTimer.start()
    }

    function advance() {
        if (current === null) return
        if (walkDir !== 0) {
            posX += walkDir * Math.max(1, current.stepPx) * px
            if ((walkDir > 0 && posX >= walkTarget) || (walkDir < 0 && posX <= walkTarget)) {
                posX = walkTarget
                walkDir = 0
                play(baseAnim())
                return
            }
        }
        if (reduced) { finish(); return }
        if (step + 1 < current.f.length) {
            step++
            schedule()
            return
        }
        // Only resting states loop; a looping reaction (happy, wave) plays one cycle.
        const resting = anim === "walk" || anim === baseAnim()
        if (!current.loop || !resting) { finish(); return }
        loops++
        if (current.settleAfterLoops > 0 && loops >= current.settleAfterLoops) {
            // Settled poses (sleep) stay still: no timer until something wakes it.
            step = 0
            settled = true
            return
        }
        step = 0
        schedule()
    }

    function finish() {
        if (anim === "yawn" && sleeping.pending) {
            sleeping.pending = false
            asleep = true
        }
        play(baseAnim())
    }

    function free(cx) {
        if (!perch || perch.avoidTo < perch.avoidFrom || perch.avoidFrom < 0) return true
        const half = hit[2] * px / 2 + 4 * s
        return cx + half < perch.avoidFrom || cx - half > perch.avoidTo
    }

    function walkTo(target) {
        if (!perch || reduced) return false
        target = Math.max(perch.minX, Math.min(perch.maxX, target))
        if (Math.abs(target - centerX) < 2 * px) return false
        posX = centerX
        walkTarget = target
        walkDir = target > centerX ? 1 : -1
        lastWalk = Date.now()
        play("walk")
        return true
    }

    // Moves off an avoided range (a playhead) toward the roomier side.
    function keepClear() {
        if (!perch || free(centerX)) return
        const half = hit[2] * px / 2 + 6 * s
        const left = perch.avoidFrom - half
        const right = perch.avoidTo + half
        const target = left - perch.minX >= perch.maxX - right ? left : right
        if (!walkTo(target)) posX = target
    }

    function clearIfIdle() {
        if (shown && walkDir === 0) keepClear()
    }

    // Timers are armed only from here; a restart() would break a running binding.
    function armBrain() {
        if (shown && !asleep && !reduced) brainTimer.restart()
        else brainTimer.stop()
    }
    function armSleep() {
        if (shown && sleepEnabled && !asleep) sleepTimer.restart()
        else sleepTimer.stop()
    }

    function wake() {
        sleeping.pending = false
        armSleep()
        if (asleep) {
            asleep = false
            play(baseAnim())
        }
    }

    function act(event) {
        const name = pack && pack.events ? pack.events[event] : ""
        if (name) play(name)
    }

    function handleEvent(kind) {
        if (!shown) return
        wake()
        if (kind === "music") play(baseAnim())
        else act(kind)
    }

    function sleepNow() {
        sleeping.pending = false
        asleep = true
        play("sleep")
    }

    function pet() {
        const now = Date.now()
        if (now - lastHappy < 2500) return
        lastHappy = now
        act("pet")
    }

    // Three clicks within 1.5 s are a pat.
    function click() {
        wake()
        const now = Date.now()
        clickTimes = clickTimes.filter(time => now - time < 1500).concat([now])
        if (clickTimes.length >= 3) {
            clickTimes = []
            pet()
        } else {
            act("click")
        }
    }

    function placeInPerch() {
        walkDir = 0
        posX = perch ? perch.restX : 0
        asleep = false
        sleeping.pending = false
        if (shown) play(baseAnim())
        else frameTimer.stop()
        armSleep()
        armBrain()
    }

    onPerchChanged: placeInPerch()
    onShownChanged: placeInPerch()
    onAsleepChanged: { armBrain(); armSleep() }
    onReducedChanged: {
        armBrain()
        if (shown) play(baseAnim())
    }
    onSleepEnabledChanged: {
        if (!sleepEnabled) {
            sleeping.pending = false
            if (asleep) {
                asleep = false
                play(baseAnim())
            }
        }
        armSleep()
    }
    Connections {
        target: actor.perch
        function onMoodChanged() { if (!actor.asleep && actor.walkDir === 0) actor.play(actor.baseAnim()) }
        // Both ends of the range move together; check once they have settled.
        function onAvoidFromChanged() { Qt.callLater(actor.clearIfIdle) }
        function onAvoidToChanged() { Qt.callLater(actor.clearIfIdle) }
    }

    QtObject {
        id: sleeping
        property bool pending: false
    }

    Timer {
        id: frameTimer
        repeat: false
        onTriggered: actor.advance()
    }

    Timer {
        id: brainTimer
        repeat: false
        interval: 4000
        onTriggered: {
            interval = 3000 + Math.floor(Math.random() * 4000)
            if (actor.anim === "idle") {
                const roomy = actor.perch.maxX - actor.perch.minX > 3 * actor.hit[2] * actor.px
                const roll = Math.random()
                if (roomy && roll < 0.22 && Date.now() - actor.lastWalk > 20000) {
                    const span = actor.perch.maxX - actor.perch.minX
                    let target = actor.perch.minX + Math.random() * span
                    for (let tries = 0; tries < 4 && !actor.free(target); tries++)
                        target = actor.perch.minX + Math.random() * span
                    if (actor.free(target)) actor.walkTo(target)
                } else if (roll < 0.6) {
                    actor.act("blink")
                } else if (roll < 0.85) {
                    actor.act(Math.random() < 0.5 ? "lookLeft" : "lookRight")
                } else if (actor.perch.kind === "edge") {
                    actor.act("perchEdge")
                }
            }
            actor.armBrain()
        }
    }

    Timer {
        id: sleepTimer
        repeat: false
        interval: actor.sleepAfterMs
        onTriggered: {
            if (!actor.sleepEnabled) return
            if (actor.walkDir !== 0 || hitArea.containsMouse || actor.baseAnim() === "dance") { actor.armSleep(); return }
            sleeping.pending = true
            actor.play("yawn")
        }
    }

    PetSprite {
        source: PetPack.atlas
        frame: actor.current ? actor.current.f[Math.min(actor.step, actor.current.f.length - 1)] : 0
        frameCount: actor.pack ? actor.pack.frameCount : 1
        frameWidth: actor.canvasW
        frameHeight: actor.canvasH
        px: actor.px
        mirrored: actor.walkDir < 0
    }

    // The body is the only target: the transparent canvas never takes input.
    MouseArea {
        id: hitArea
        x: actor.hit[0] * actor.px
        y: actor.hit[1] * actor.px
        width: actor.hit[2] * actor.px
        height: actor.bodyRows * actor.px
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton
        cursorShape: Qt.PointingHandCursor
        Accessible.ignored: true
        onEntered: {
            actor.wake()
            actor.strokes = 0
            actor.strokeLastX = -1
            if (actor.anim === actor.baseAnim() && actor.walkDir === 0) actor.act("hover")
        }
        onPositionChanged: mouse => {
            // A stroke is the cursor going back and forth across the body.
            const now = Date.now()
            if (actor.strokeLastX >= 0 && Math.abs(mouse.x - actor.strokeLastX) >= 3 * actor.s) {
                const dir = mouse.x > actor.strokeLastX ? 1 : -1
                if (actor.strokeDir !== 0 && dir !== actor.strokeDir) {
                    if (now - actor.strokeStart > 1500) { actor.strokes = 0; actor.strokeStart = now }
                    if (++actor.strokes >= 3) { actor.strokes = 0; actor.pet() }
                }
                actor.strokeDir = dir
                actor.strokeLastX = mouse.x
            } else if (actor.strokeLastX < 0) {
                actor.strokeLastX = mouse.x
                actor.strokeStart = now
            }
        }
        onClicked: actor.click()
    }
}
